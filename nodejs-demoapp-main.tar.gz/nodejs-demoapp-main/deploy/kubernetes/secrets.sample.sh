kubectl create secret generic nodejs-demoapp \
--from-literal=weatherKey=CHANGEME \
--from-literal=aadAppSecret=CHANGEME